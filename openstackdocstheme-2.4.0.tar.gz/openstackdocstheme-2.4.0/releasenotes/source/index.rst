===================================
 OpenStack Docs Theme Release Notes
===================================

.. toctree::
   :maxdepth: 1

   current
   historic
