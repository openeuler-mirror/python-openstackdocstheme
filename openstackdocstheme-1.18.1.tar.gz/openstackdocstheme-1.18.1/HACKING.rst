OpenStack Docs Theme Style Commandments
=======================================

- Step 1: Read the OpenStack Style Commandments
  https://docs.openstack.org/hacking/latest/
- Step 2: Read on

Our Specific Commandments
---------------------------------

Refer to https://wiki.openstack.org/wiki/Documentation/Conventions
