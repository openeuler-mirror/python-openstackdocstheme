========================
Team and repository tags
========================

.. image:: https://governance.openstack.org/tc/badges/openstackdocstheme.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html

.. Change things from this point on

OpenStack docs.openstack.org Sphinx Theme
=========================================

Theme and extension support for Sphinx documentation that is published to
docs.openstack.org and developer.openstack.org.

Intended for use by OpenStack `projects governed by the Technical Committee`_.

.. _`projects governed by the Technical Committee`: https://governance.openstack.org/tc/reference/projects/index.html

* Free software: Apache License, Version 2.0
* Documentation: https://docs.openstack.org/openstackdocstheme/latest/
* Release notes: https://docs.openstack.org/releasenotes/openstackdocstheme/
* Source: https://git.openstack.org/cgit/openstack/openstackdocstheme
* Bugs: https://launchpad.net/openstack-doc-tools
